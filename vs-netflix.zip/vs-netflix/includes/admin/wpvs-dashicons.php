<div class="wpvs-dashicons-select">
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-menu"></span>
        <span class="badge">menu</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-site"></span>
        <span class="badge">admin-site</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-dashboard"></span>
        <span class="badge">dashboard</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-post"></span>
        <span class="badge">admin-post</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-media"></span>
        <span class="badge">admin-media</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-links"></span>
        <span class="badge">admin-links</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-page"></span>
        <span class="badge">admin-page</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-comments"></span>
        <span class="badge">admin-comments</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-appearance"></span>
        <span class="badge">admin-appearance</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-plugins"></span>
        <span class="badge">admin-plugins</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-users"></span>
        <span class="badge">admin-users</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-groups"></span>
        <span class="badge">groups</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-businessman"></span>
        <span class="badge">businessman</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-tools"></span>
        <span class="badge">admin-tools</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-settings"></span>
        <span class="badge">admin-settings</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-network"></span>
        <span class="badge">admin-network</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-home"></span>
        <span class="badge">admin-home</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-generic"></span>
        <span class="badge">admin-generic</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-admin-collapse"></span>
        <span class="badge">admin-collapse</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-welcome-write-blog"></span>
        <span class="badge">welcome-write-blog</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-welcome-add-page"></span>
        <span class="badge">welcome-add-page</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-welcome-view-site"></span>
        <span class="badge">welcome-view-site</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-welcome-widgets-menus"></span>
        <span class="badge">welcome-widgets-menus</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-welcome-comments"></span>
        <span class="badge">welcome-comments</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-welcome-learn-more"></span>
        <span class="badge">welcome-learn-more</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-format-aside"></span>
        <span class="badge">format-aside</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-format-image"></span>
        <span class="badge">format-image</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-format-gallery"></span>
        <span class="badge">format-gallery</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-format-video"></span>
        <span class="badge">format-video</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-format-status"></span>
        <span class="badge">format-status</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-format-quote"></span>
        <span class="badge">format-quote</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-format-chat"></span>
        <span class="badge">format-chat</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-format-audio"></span>
        <span class="badge">format-audio</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-camera"></span>
        <span class="badge">camera</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-images-alt"></span>
        <span class="badge">images-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-images-alt2"></span>
        <span class="badge">images-alt2</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-video-alt"></span>
        <span class="badge">video-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-video-alt2"></span>
        <span class="badge">video-alt2</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-video-alt3"></span>
        <span class="badge">video-alt3</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-image-crop"></span>
        <span class="badge">image-crop</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-image-rotate-left"></span>
        <span class="badge">image-rotate-left</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-image-rotate-right"></span>
        <span class="badge">image-rotate-right</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-image-flip-vertical"></span>
        <span class="badge">image-flip-vertical</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-image-flip-horizontal"></span>
        <span class="badge">image-flip-horizontal</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-undo"></span>
        <span class="badge">undo</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-redo"></span>
        <span class="badge">redo</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-bold"></span>
        <span class="badge">editor-bold</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-italic"></span>
        <span class="badge">editor-italic</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-ul"></span>
        <span class="badge">editor-ul</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-ol"></span>
        <span class="badge">editor-ol</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-quote"></span>
        <span class="badge">editor-quote</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-alignleft"></span>
        <span class="badge">editor-alignleft</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-aligncenter"></span>
        <span class="badge">editor-aligncenter</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-alignright"></span>
        <span class="badge">editor-alignright</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-insertmore"></span>
        <span class="badge">editor-insertmore</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-spellcheck"></span>
        <span class="badge">editor-spellcheck</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-distractionfree"></span>
        <span class="badge">editor-distractionfree</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-kitchensink"></span>
        <span class="badge">editor-kitchensink</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-underline"></span>
        <span class="badge">editor-underline</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-justify"></span>
        <span class="badge">editor-justify</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-textcolor"></span>
        <span class="badge">editor-textcolor</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-paste-word"></span>
        <span class="badge">editor-paste-word</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-paste-text"></span>
        <span class="badge">editor-paste-text</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-removeformatting"></span>
        <span class="badge">editor-removeformatting</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-video"></span>
        <span class="badge">editor-video</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-customchar"></span>
        <span class="badge">editor-customchar</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-outdent"></span>
        <span class="badge">editor-outdent</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-indent"></span>
        <span class="badge">editor-indent</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-help"></span>
        <span class="badge">editor-help</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-strikethrough"></span>
        <span class="badge">editor-strikethrough</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-unlink"></span>
        <span class="badge">editor-unlink</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-editor-rtl"></span>
        <span class="badge">editor-rtl</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-align-left"></span>
        <span class="badge">align-left</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-align-right"></span>
        <span class="badge">align-right</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-align-center"></span>
        <span class="badge">align-center</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-align-none"></span>
        <span class="badge">align-none</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-lock"></span>
        <span class="badge">lock</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-calendar"></span>
        <span class="badge">calendar</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-visibility"></span>
        <span class="badge">visibility</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-post-status"></span>
        <span class="badge">post-status</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-edit"></span>
        <span class="badge">edit</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-trash"></span>
        <span class="badge">trash</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-arrow-up"></span>
        <span class="badge">arrow-up</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-arrow-down"></span>
        <span class="badge">arrow-down</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-arrow-right"></span>
        <span class="badge">arrow-right</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-arrow-left"></span>
        <span class="badge">arrow-left</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-arrow-up-alt"></span>
        <span class="badge">arrow-up-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-arrow-down-alt"></span>
        <span class="badge">arrow-down-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-arrow-right-alt"></span>
        <span class="badge">arrow-right-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-arrow-left-alt"></span>
        <span class="badge">arrow-left-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-arrow-up-alt2"></span>
        <span class="badge">arrow-up-alt2</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-arrow-down-alt2"></span>
        <span class="badge">arrow-down-alt2</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-arrow-right-alt2"></span>
        <span class="badge">arrow-right-alt2</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-arrow-left-alt2"></span>
        <span class="badge">arrow-left-alt2</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-sort"></span>
        <span class="badge">sort</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-leftright"></span>
        <span class="badge">leftright</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-list-view"></span>
        <span class="badge">list-view</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-exerpt-view"></span>
        <span class="badge">exerpt-view</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-share"></span>
        <span class="badge">share</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-share-alt"></span>
        <span class="badge">share-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-share-alt2"></span>
        <span class="badge">share-alt2</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-twitter"></span>
        <span class="badge">twitter</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-rss"></span>
        <span class="badge">rss</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-facebook"></span>
        <span class="badge">facebook</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-facebook-alt"></span>
        <span class="badge">facebook-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-googleplus"></span>
        <span class="badge">googleplus</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-networking"></span>
        <span class="badge">networking</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-hammer"></span>
        <span class="badge">hammer</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-art"></span>
        <span class="badge">art</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-migrate"></span>
        <span class="badge">migrate</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-performance"></span>
        <span class="badge">performance</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-wordpress"></span>
        <span class="badge">wordpress</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-wordpress-alt"></span>
        <span class="badge">wordpress-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-pressthis"></span>
        <span class="badge">pressthis</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-update"></span>
        <span class="badge">update</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-screenoptions"></span>
        <span class="badge">screenoptions</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-info"></span>
        <span class="badge">info</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-cart"></span>
        <span class="badge">cart</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-feedback"></span>
        <span class="badge">feedback</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-cloud"></span>
        <span class="badge">cloud</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-translation"></span>
        <span class="badge">translation</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-tag"></span>
        <span class="badge">tag</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-category"></span>
        <span class="badge">category</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-yes"></span>
        <span class="badge">yes</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-no"></span>
        <span class="badge">no</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-no-alt"></span>
        <span class="badge">no-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-plus"></span>
        <span class="badge">plus</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-minus"></span>
        <span class="badge">minus</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-dismiss"></span>
        <span class="badge">dismiss</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-marker"></span>
        <span class="badge">marker</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-star-filled"></span>
        <span class="badge">star-filled</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-star-half"></span>
        <span class="badge">star-half</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-star-empty"></span>
        <span class="badge">star-empty</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-flag"></span>
        <span class="badge">flag</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-location"></span>
        <span class="badge">location</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-location-alt"></span>
        <span class="badge">location-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-vault"></span>
        <span class="badge">vault</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-shield"></span>
        <span class="badge">shield</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-shield-alt"></span>
        <span class="badge">shield-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-search"></span>
        <span class="badge">search</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-slides"></span>
        <span class="badge">slides</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-analytics"></span>
        <span class="badge">analytics</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-chart-pie"></span>
        <span class="badge">chart-pie</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-chart-bar"></span>
        <span class="badge">chart-bar</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-chart-line"></span>
        <span class="badge">chart-line</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-chart-area"></span>
        <span class="badge">chart-area</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-id"></span>
        <span class="badge">id</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-id-alt"></span>
        <span class="badge">id-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-products"></span>
        <span class="badge">products</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-awards"></span>
        <span class="badge">awards</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-forms"></span>
        <span class="badge">forms</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-portfolio"></span>
        <span class="badge">portfolio</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-book"></span>
        <span class="badge">book</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-book-alt"></span>
        <span class="badge">book-alt</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-download"></span>
        <span class="badge">download</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-upload"></span>
        <span class="badge">upload</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-backup"></span>
        <span class="badge">backup</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-lightbulb"></span>
        <span class="badge">lightbulb</span>
    </div>
    <div class="wpvs-dashicon-option">
        <span class="dashicons dashicons-smiley"></span>
        <span class="badge">smiley</span>
    </div>
</div>