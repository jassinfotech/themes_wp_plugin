<?php
global $wpvs_theme_gutenberg_blocks_dir;
$wpvs_theme_gutenberg_blocks_dir = get_template_directory_uri() . '/gutenberg-blocks';
include 'full-section/index.php';
include 'category-slider/index.php';
