<?php

if( is_admin() ) {
    require_once('admin/term-meta.php');
}
