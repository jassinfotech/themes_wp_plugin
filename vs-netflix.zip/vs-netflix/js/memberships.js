jQuery(document).ready(function() {
    jQuery("#close-wpvs-checkout").click(function () {
        jQuery('.wpvs-term-checkout').fadeOut();
    });                                       
});