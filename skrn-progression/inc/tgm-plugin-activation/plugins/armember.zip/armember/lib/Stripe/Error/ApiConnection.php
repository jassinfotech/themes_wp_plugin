<?php

namespace Stripe\Error;

class Stripe_ApiConnection extends Base
{
}
